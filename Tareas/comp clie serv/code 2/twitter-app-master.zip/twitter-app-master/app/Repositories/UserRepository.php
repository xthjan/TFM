<?php

namespace App\Repositories;

use App\Models\User;

class UserRepository
{
    public function findByUsername(string $username)
    {
        $user = DBConnector::select("select * from users where username = ?", [$username]);
        if ($user != null) {
            return new User((array) $user[0]);
        }
        return null;
    }

    public function save(User $user)
    {
        DBConnector::insert('INSERT INTO users (name, username, password) VALUES (?, ?, ?)', [$user->name, $user->username, $user->hashedPassword]);

        // Recover user to have user id
        $dbUser = DBConnector::select("select * from users where username = ?", [$user->username]);
        return new User((array) $dbUser[0]);
    }
}
