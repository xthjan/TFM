<?php

namespace App\Repositories;

use App\Models\Tweet;
use App\Models\User;

class TweetRepository
{
    public function findAll()
    {
        $rawTweets = DBConnector::select('SELECT u.*, t.* FROM tweets t INNER JOIN users u ON t.user_id = u.id ORDER BY t.created_at DESC');
        $tweets = [];
        foreach ($rawTweets as $rawTweet) {
            $tweet = new Tweet((array) $rawTweet);
            $tweet->createdBy = new User((array) $rawTweet);
            $tweet->createdBy->id = $rawTweet['user_id'];
            $tweets[] = $tweet;
        }
        return $tweets;
    }

    public function save(Tweet $tweet)
    {
        DBConnector::insert('INSERT INTO tweets (content, user_id, created_at) VALUES (?, ?, ?)', [$tweet->content, $tweet->createdBy->id, date("Y:m:d H:i:s")]);
    }
}
