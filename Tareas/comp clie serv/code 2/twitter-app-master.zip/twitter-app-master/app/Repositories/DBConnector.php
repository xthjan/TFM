<?php

namespace App\Repositories;

use Exception;

class DBConnector
{

    public static function select(string $query, $bindings = [])
    {
        $connection = self::getConnection();
        $statement = $connection->prepare($query);

        if (!$statement) {
            throw new Exception('Failed to create statement: ' . $query);
        }

        if (sizeof($bindings) > 0) {
            $types = '';
            foreach ($bindings as $binding) {
                if (is_float($binding)) $types .= 'd';
                elseif (is_integer($binding)) $types .= 'i';
                elseif (is_string($binding)) $types .= 's';
                else $types .= 'b';
            }

            $statement->bind_param($types, ...$bindings);
        }


        $statement->execute();

        $result = $statement->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);


        $statement->close();
        $connection->close();

        return $data;
    }

    public static function insert(string $query, $bindings = [])
    {
        $connection = self::getConnection();
        $statement = $connection->prepare($query);

        if (!$statement) {
            throw new Exception('Failed to create statement: ' . $query);
        }

        if (sizeof($bindings) > 0) {
            $types = '';
            foreach ($bindings as $binding) {
                if (is_float($binding)) $types .= 'd';
                elseif (is_integer($binding)) $types .= 'i';
                elseif (is_string($binding)) $types .= 's';
                else $types .= 'b';
            }

            $statement->bind_param($types, ...$bindings);
        }


        $statement->execute();

        $result = $statement->get_result();


        $statement->close();
        $connection->close();

        return $result;
    }

    private static function getConnection()
    {
        $connection = new \mysqli(
            env('DB_HOST'),
            env('DB_USERNAME'),
            env('DB_PASSWORD'),
            env('DB_DATABASE')
        );

        if (mysqli_connect_errno()) {
            throw new Exception('Database connection failed');
        }

        return $connection;
    }
}
