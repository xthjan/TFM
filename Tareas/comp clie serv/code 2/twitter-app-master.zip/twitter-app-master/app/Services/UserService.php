<?php

namespace App\Services;

use App\Models\User;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Hash;

class UserService
{
    private $repository;

    public function __construct()
    {
        $this->repository = new UserRepository();
    }

    public function createUser(User $user)
    {
        $dbUser = $this->repository->findByUsername($user->username);
        if ($dbUser == null) {
            $user->hashedPassword = Hash::make($user->password);
            return $this->repository->save($user);
        }
        return null;
    }

    public function checkUser(User $user)
    {
        $dbUser = $this->repository->findByUsername($user->username);
        if ($dbUser != null && Hash::check($user->password, $dbUser->hashedPassword)) {
            return $dbUser;
        }
        return null;
    }
}
