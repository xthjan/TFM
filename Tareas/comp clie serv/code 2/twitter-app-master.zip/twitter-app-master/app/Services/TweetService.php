<?php

namespace App\Services;

use App\Models\Tweet;
use App\Models\User;
use App\Repositories\TweetRepository;

class TweetService
{
    private $repository;

    public function __construct()
    {
        $this->repository = new TweetRepository();
    }

    public function create(string $content, User $user)
    {
        $tweet = new Tweet([
            'content' => $content,
            'user' => $user,
        ]);
        $this->repository->save($tweet);
    }

    public function findAll()
    {
        return $this->repository->findAll();
    }
}
