<?php

namespace App\Models;

class Tweet extends BaseModel
{
    public $id;
    public $content;
    public $createdAt;
    public $createdBy;

    public function __construct($params)
    {
        $this->id = $params['id'] ?? null;
        $this->content = $params['content'] ?? null;
        $this->createdAt = $params['created_at'] ?? null;
        $this->createdBy = $params['user'] ?? null;
    }
}
