<?php

namespace App\Models;

class User extends BaseModel
{
    public $id;
    public $name;
    public $username;
    public $password;
    public $hashedPassword;

    public function __construct($params)
    {
        $this->id = $params['id'] ?? null;
        $this->name = $params['name'] ?? null;
        $this->username = $params['username'] ?? null;
        $this->password = $params['password'] ?? null;
        $this->hashedPassword = $params['password'] ?? null;
    }
}
