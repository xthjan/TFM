<?php

namespace App\Models;

class BaseModel
{
}
