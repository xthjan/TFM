<?php

namespace App\Http\Controllers;

use App\Services\TweetService;
use Illuminate\Http\Request;

class FeedController extends Controller
{
    private $tweetService;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(TweetService $service)
    {
        $this->tweetService = $service;
    }

    public function listAll()
    {
        $tweets = $this->tweetService->findAll();
        return response()->json(['tweets' => $tweets]);
    }

    public function index(Request $request)
    {
        $user = $request->session()->get('user');
        return view('feed.index', ['user' => $user]);
    }

    public function postTweet(Request $request)
    {
        $user = $request->session()->get('user');
        $content = $request->get('content');
        $this->tweetService->create($content, $user);
        return redirect()->route('feed');
    }
}
