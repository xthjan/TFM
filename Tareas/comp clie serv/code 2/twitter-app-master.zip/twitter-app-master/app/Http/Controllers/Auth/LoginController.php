<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Services\UserService;
use Illuminate\Http\Request;
use App\Models\User;

class LoginController extends Controller
{
    private $userService;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }


    public function index()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $inputUser = new User($request->all());

        $user = $this->userService->checkUser($inputUser);
        if ($user != null) {
            $request->session()->put('user', $user);
            return response()->json(['login' => 'ok']);
        }

        return response()->json(['error' => 'Unauthorized'], 401);
    }

    public function logout(Request $request)
    {
        $request->session()->flush();
        return redirect()->route('login');
    }
}
