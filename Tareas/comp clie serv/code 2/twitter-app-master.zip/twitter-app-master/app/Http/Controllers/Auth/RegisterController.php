<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Services\UserService;
use Illuminate\Http\Request;
use App\Models\User;

class RegisterController extends Controller
{
    private $userService;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }


    public function index()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $inputUser = new User($request->all());
        $user = $this->userService->createUser($inputUser);
        if ($user != null) {
            $request->session()->put('user', $user);
            return response()->json(['login' => 'ok']);
        }
        return response()->json(['error' => 'Bad Request'], 400);
    }
}
