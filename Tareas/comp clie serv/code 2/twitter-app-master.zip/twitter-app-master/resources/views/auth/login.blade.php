@extends('layouts.app')


@section('content')

<div style="margin: auto" class="max-w-md">
  <div class="bg-white shadow overflow-hidden sm:rounded-lg mt-6 p-12 pt-0">

    <p class="mt-8 text-right">
      <a class="text-blue-700 hover:underline" href="/register">Registrarse</a>
    </p>

    <h2 class="text-2xl font-bold">Iniciar sesión</h2>
    <form class="mt-8" id="login_form">
      <div class="grid grid-cols-1 gap-6">
        <label class="block">
          <span class="text-gray-700">Nombre de usuario</span>
          <input type="text" name="username"
            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            required>
        </label>

        <label class="block">
          <span class="text-gray-700">Contraseña</span>
          <input type="password" name="password"
            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            required>
          <span id="login_error" style="display:none" class="text-red-600 text-sm">El usuario o contraseña no son
            válidos</span>
        </label>

        <label class="block">
          <button id="form_button" type="submit"
            class="mt-1 block w-full py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
            <svg id="loading_spinner" class="animate-spin h-5 w-5 text-white mx-auto" xmlns="http://www.w3.org/2000/svg"
              fill="none" viewBox="0 0 24 24" style="display:none">
              <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
              <path class="opacity-75" fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z">
              </path>
            </svg>
            <span id="button_text">
              Iniciar sesión
            </span>
          </button>
        </label>

      </div>
    </form>
  </div>
</div>

<script>
  function startSpinner() {
    form_button.disabled = 'disabled';
    form_button.classList.add('cursor-not-allowed');
    loading_spinner.style.display = 'block';
    button_text.style.display = 'none';
  }

  function stopSpinner() {
    form_button.disabled = '';
    form_button.classList.remove('cursor-not-allowed');
    loading_spinner.style.display = 'none';
    button_text.style.display = 'inline-block';
  }

  function hideError() {
    login_error.style.display = 'none';
  }

  function showError() {
    login_error.style.display = 'block';
  }

  function login(username, password) {
    hideError();
    fetch('/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({username, password})
    })
    .then(response => {
      if (!response.ok) {
        stopSpinner();
        showError();
      } else {
        location.href = '/';
      }
    })
    .catch(error => {
      stopSpinner();
      showError();
    });
  }


  login_form.addEventListener('submit', function(event) {
    event.preventDefault();

    startSpinner();

    const data = new FormData(event.target);
    login(data.get('username'), data.get('password'));
  });
</script>
@endsection
