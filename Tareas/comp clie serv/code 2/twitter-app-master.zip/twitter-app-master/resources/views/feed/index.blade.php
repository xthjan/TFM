@extends('layouts.app')


@section('content')

<div class="max-w-2xl border border-gray-200 h-auto border-t-0 bg-white" style="margin:auto">

  <div class="flex">
    <div class="flex-1 m-2">
      <h2 class="px-4 py-2 text-xl font-semibold">Inicio</h2>
    </div>

    <p class="m-4 text-right">
      <a class="text-blue-700 hover:underline" href="/logout">Cerrar sesión</a>
    </p>
  </div>

  <hr class="border-gray-200">
  <form id="tweet_form">
    <div class="flex">
      <div class="m-2 w-10 py-1">
        <img class="inline-block h-10 w-10 rounded-full" src="https://i.pravatar.cc/150?img={{ $user->id ?? '1' }}"
          alt="" />
      </div>
      <div class="flex-1 px-2 pt-2 mt-2">
        <textarea id="tweet_content" name="content" class=" bg-transparent text-gray-600 font-medium text-lg w-full"
          rows="2" cols="50" placeholder="¿Qué está pasando?"></textarea>
      </div>
    </div>


    <div class="flex">
      <div class="flex-1">
        <button id="form_button" type="submit"
          class="bg-blue-400 m-4 hover:bg-blue-600 text-white font-bold py-2 px-8 rounded-full mr-8 float-right ">
          <svg id="loading_spinner" class="animate-spin h-5 w-5 text-white mx-auto" xmlns="http://www.w3.org/2000/svg"
            fill="none" viewBox="0 0 24 24" style="display:none">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z">
            </path>
          </svg>
          <span id="button_text">
            Tweet
          </span>
        </button>
      </div>
    </div>
  </form>

  <hr class="border-gray-100 border-4">


  <div id="tweets_container">
  </div>
</div>


<script>
  function startSpinner() {
    form_button.disabled = 'disabled';
    form_button.classList.add('cursor-not-allowed');
    loading_spinner.style.display = 'block';
    button_text.style.display = 'none';
  }

  function stopSpinner() {
    form_button.disabled = '';
    form_button.classList.remove('cursor-not-allowed');
    loading_spinner.style.display = 'none';
    button_text.style.display = 'inline-block';
  }

  function sendTweet(content) {
    fetch('/tweet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({content})
    })
    .then(response => {
      stopSpinner();
      if (response.ok) {
        tweet_content.value = '';
      }
    })
    .catch(error => {
      stopSpinner();
    });
  }


  tweet_form.addEventListener('submit', function(event) {
    event.preventDefault();
    startSpinner();

    const data = new FormData(event.target);
    sendTweet(data.get('content'));
  });

  const rtf = new Intl.RelativeTimeFormat('es', { numeric: 'auto' });
  function timeAgo(date) {
    const diff = Math.floor((date - Date.now()) / 1000);
    if (Math.abs(diff) < 60) {
      return rtf.format(diff, 'seconds');
    } else if (Math.abs(diff) < 3600) {
      return rtf.format(Math.floor(diff / 60) + 1, 'minutes');
    }
    return rtf.format(Math.floor(diff / 3600) + 1, 'hours');
  }

  let tweets = [];

  function enqueueReload() {
    setTimeout(fetchTweets, 4000);
  }

  function fetchTweets() {
    fetch('/feed')
      .then(res => res.json())
      .then(data => {
        reloadTweets(data.tweets);
        enqueueReload();
      });
  }

  function reloadTweets(newTweets) {
    if (newTweets.length === tweets.length) {
      return;
    }
    tweets = newTweets;

    let content = '';
    for (const tweet of tweets) {
      content += TweetComponent(tweet);
    }
    tweets_container.innerHTML = content;
  }

  function TweetComponent({content, createdAt, createdBy}) {
    return `
    <div class="pt-4 pb-4">
      <div class="flex flex-shrink-0 pl-4 pr-4">
        <div class="flex items-center">
          <div>
            <img class="inline-block h-10 w-10 rounded-full"
              src="https://i.pravatar.cc/150?img=${ createdBy.id }" alt="" />
          </div>
          <div class="ml-3">
            <p class="text-base leading-6 font-medium">
              ${ createdBy.name }
              <span
                class="text-sm leading-5 font-medium text-gray-400 group-hover:text-gray-300 transition ease-in-out duration-150">
                @${ createdBy.username } ·
                ${ timeAgo(Date.parse(createdAt+'Z')) }
              </span>
            </p>
          </div>
        </div>
      </div>
      <div class="pl-16">
        <p class="text-base width-auto flex-shrink text-gray-900">
          ${ content }
        </p>

      </div>
    </div>
    <hr class="border-gray-200">
    `;
  }

  fetchTweets();
</script>

@endsection
