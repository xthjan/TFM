<!doctype html>

<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Twitter</title>
  <link href="https://unpkg.com/tailwindcss@next/dist/base.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/@tailwindcss/forms@0.2.1/dist/forms.min.css" rel="stylesheet">
  <link href="https://unpkg.com/tailwindcss@next/dist/components.min.css" rel="stylesheet">
  <link href="https://unpkg.com/tailwindcss@next/dist/utilities.min.css" rel="stylesheet">
</head>

<body class="bg-gray-100">
  @yield('content')
</body>

</html>
