# Instrucciones

La configuración del proyecto se realiza mediante variables de entorno. A su vez, por simplicidad, también se puede configurar de la siguiente manera:

Copiando el fichero `.env.example` y llamándolo `.env`:

```
cp .env.example .env
```

Sustituir las variables dentro de ese fichero por las que correspondan. Las más importantes, para la conexión con la base de datos son:

```
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=twitterapp
DB_USERNAME=root
DB_PASSWORD=secret
```

## Levantar el proyecto

El proyecto se puede levantar tanto en local, como usando Docker.

### Con Docker

Esta es la manera más sencilla, ya que no es necesario configurar nada.

Ejecutando en la raíz del proyecto lo siguiente:
```
docker-compose up
```

Después de esperar unos momentos a que todo se levante correctamente, ya tendríamos disponible:

- La web en `localhost:18000`
- La base de datos MariaDB en `localhost:13306`
- La web de [Adminer](https://www.adminer.org/) en `localhost:18080`

### En local

Para la gestión de librerías externas se utiliza la herramienta [Composer](https://getcomposer.org/).

Una vez instalado habría que ejecutar, en la raíz del proyecto, lo siguiente:

```
composer install
```

Esto nos descargaría toda las dependencias necesarias.

> **Aviso:** Es importante tener bien configurado nuestro fichero de `.env` para que lo siguiente funcione.

La estructura base de datos se crea usando [migraciones de Laravel](https://laravel.com/docs/8.x/migrations).
Teniendo la base de datos ya creada y levantada, ejecutamos lo siguiente desde la raíz del proyecto:

```
php artisan migrate
```
