<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', ['middleware' => 'auth', 'uses' => 'FeedController@index', 'as' => 'feed']);
$router->get('/feed', ['middleware' => 'auth', 'uses' => 'FeedController@listAll', 'as' => 'listAll']);
$router->post('/tweet', ['middleware' => 'auth', 'uses' => 'FeedController@postTweet', 'as' => 'postTweet']);

$router->get('/login', ['uses' => 'Auth\\LoginController@index', 'as' => 'login']);
$router->post('/login', ['uses' => 'Auth\\LoginController@login', 'as' => 'doLogin']);
$router->get('/logout', ['uses' => 'Auth\\LoginController@logout', 'as' => 'logout']);

$router->get('/register', ['uses' => 'Auth\\RegisterController@index', 'as' => 'register']);
$router->post('/register', ['uses' => 'Auth\\RegisterController@register', 'as' => 'doRegister']);
